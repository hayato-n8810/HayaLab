from ..classes.repo import Repo


def fetch_repos_from_ranking(lang, n=1000) -> list[Repo]:
    """a"""
    return [Repo(i) for i in range(100)]
