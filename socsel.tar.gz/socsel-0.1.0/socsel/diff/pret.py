import re

from ..util.file import make_file
from ..util.shell import exec


def remove_comment(code: str):
    return exec("node", "comment_remover.js", make_file(code))


def lint(code: str, error):
    code = "\n" + code
    if error == "no-unused-vars":
        filter_error = lambda x: "no-unused-vars" in x and "'_'" not in x
    else:
        filter_error = lambda _: True

    result = []
    for line in exec(
        "npx", "eslint", "-c", ".eslintrc.json", make_file(code)
    ).split("\n"):
        if filter_error(line):
            l, c = map(int, re.match(r".{4} *.{4}(\d+):(\d+)", line).groups())
            result.append(sum(map(len, code.split("\n")[: l - 1])) + l - 1 + c - 1 - 1)

    return result


def find_identifiers(pattern, declarations, after=False):
    if type(pattern) is str:
        return

    if type(pattern) is list:
        for value in pattern:
            find_identifiers(value, declarations, after=after)
        return

    if (
        pattern[0] == "Identifier"
        and pattern[1]["value"] not in self.identifiers
        and pattern[1]["value"] in declarations
    ):
        self.identifiers.append(pattern[1]["value"])
    elif (
        pattern[0] == "Literal"
        and not after
        and pattern[1]["value"] not in self.identifiers
        and pattern[1]["value"] not in ("0", "1")
    ):
        self.identifiers.append(pattern[1]["value"])

    if pattern[0] == "Identifier" or pattern[0] == "Literal":
        if pattern[1]["value"] in self.identifiers:
            pattern[1]["index"] = self.identifiers.index(pattern[1]["value"])
            del pattern[1]["value"]
        return

    for value in pattern[1].values():
        self.find_identifiers(value, declarations, after=after)


def abstract_code(code, literals, declarations):
    i = 0
    for node in sorted(declarations + literals, key=lambda x: x[0]["start"]):
        if node.token != "0" and node.token != "1":
            code = code[: node["start"] + i] + node["type"] + code[node["end"] + i :]
            i += len(node["type"]) - len(node.token)

    return code


def __init__():
    identifiers = []
    find_identifiers(self.base.patterns, self.base.declarations)
    find_identifiers(self.head.patterns, self.head.declarations, after=True)
