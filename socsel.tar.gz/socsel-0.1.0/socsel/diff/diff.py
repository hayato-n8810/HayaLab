from ..classes.ast import AST, GumtreeDiff, GumtreeAction
from ..util.file import make_file
from ..util.shell import exec_json


# def gumtree(ast_pair: Pair[AST]):
def gumtree(ast1: AST, ast2: AST):
    labels1 = {node.label: i for i, node in enumerate(ast1.tree)}
    labels2 = {node.label: i for i, node in enumerate(ast2.tree)}

    result = exec_json(
        "gumtree", "textdiff", "-f", "JSON", *make_file(ast1.code, ast2.code)
    )

    """
    matching = {pair["src"]: pair["dest"] for pair in result["matches"]}

    diff = []

    for action in result["actions"]:
        action_name = action["action"].split("-")[0]

        match action_name:
            case "delete":
                diff_node = (labels1[action["tree"]], None)
            case "insert":
                diff_node = (None, labels2[action["tree"]])
            case "move" | "update":
                diff_node = (
                    labels1[action["tree"]],
                    labels2[matching[action["tree"]]],
                )

        diff.append(GumtreeDiffNode(action_name, *diff_node))

        match action["action"]:
            case "delete-tree":
                for node1 in filter(lambda x: diff_node[0] in x.parent, ast1.tree):
                    diff_node2 = (labels1[node1.label], None)
                    diff.append(GumtreeDiffNode(action_name, *diff_node2))

            case "insert-tree":
                for node2 in filter(lambda x: diff_node[0] in x.parent, ast2.tree):
                    diff_node2 = (labels2[node2.label], None)
                    diff.append(GumtreeDiffNode(action_name, *diff_node2))

            case "move-tree":
                for node1 in filter(lambda x: diff_node[0] in x.parent, ast1.tree):
                    diff_node2 = (
                        labels1[node1.label],
                        labels2[matching[node1.label]],
                    )
                    diff.append(GumtreeDiffNode(action_name, *diff_node2))


    for matched_pair in result["matches"]:
        diff.append(
            GumtreeDiffNode(
                "matched",
                labels1[matched_pair["src"]],
                labels2[matched_pair["dest"]],
            )
        )

    return sorted(diff, key=lambda x: x[1] if x[1] else -1)
    """

    return GumtreeDiff(
        sorted(
            [
                (
                    labels1[match["src"]],
                    labels2[match["dest"]],
                )
                for match in result["matches"]
            ]
        ),
        [
            GumtreeAction(
                action["action"],
                    labels1[action["tree"]] if action["tree"] in labels1 else None
            )
            for action in result["actions"]
        ],
        ast1,
        ast2
    )
