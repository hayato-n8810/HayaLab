from itertools import pairwise, product, starmap

from ..classes.ast import AST, ASTNode, GumtreeDiff, Pattern, GumtreeNodeDiff


def _pattern_diff(gumtree_diff: GumtreeDiff):
    replace_matches = []
    for action in gumtree_diff.diff:
        if action.relation in ("move", "update"):
            for j, node_diff in reversed(list(enumerate(gumtree_diff.diff))):
                if action.base in node_diff.base.parent:

                    if node_diff.base.name != node_diff.base.value:
                        replace_matches.append(node_diff)
                    
                    gumtree_diff.diff.pop(j)

    for before, after in pairwise(gumtree_diff.diff + [GumtreeNodeDiff('match', len(gumtree_diff.base_ast.tree), len(gumtree_diff.head_ast.tree))]):
        if gumtree_diff.base_ast.tree.index(before.base) + 1 != gumtree_diff.base_ast.tree.index(after.base):
            pattern1 = gumtree_diff.base_ast.tree[before[0] + 1 : after[0]]
            pattern2 = gumtree_diff.head_ast.tree[before[1] + 1 : after[1]]

            if pattern2:
                pattern_begin = min(n.begin for n in pattern2)
                pattern_end = max(n.end for n in pattern2)
                head_code = gumtree_diff.head_ast.tree[pattern_begin:pattern_end]

                replacing_code = []
                for match in replace_matches:
                    if (
                        gumtree_diff.head_ast.tree[match[1]].begin >= pattern_begin
                        and gumtree_diff.head_ast.tree[match[1]].end <= pattern_end
                    ):
                        replacing_code.append(
                            (
                                match[0] - (before[0] + 1),
                                (
                                    gumtree_diff.head_ast.tree[match[1]].begin - pattern_begin,
                                    gumtree_diff.head_ast.tree[match[1]].end - pattern_begin,
                                ),
                            )
                        )

                yield Pattern(pattern1, head_code, replacing_code)
            else:
                yield Pattern(pattern1, "", [])


def pattern_diff(gumtree_diff: GumtreeDiff):
    for action in gumtree_diff.actions:
        if action.name in ("move-node", "move-tree", "update-node", "update-tree"):

            for i, match in enumerate(gumtree_diff.matches):
                if match[0] == action.tree:
                    gumtree_diff.matches.pop(i)

                    for j, m in reversed(list(enumerate(gumtree_diff.matches))):
                        if match[0] in gumtree_diff.base_ast.tree[m[0]].parent:
                            gumtree_diff.base_ast.tree[gumtree_diff.matches.pop(j)[0]]

                    break
    #
    # filter(lambda x: diff.base[x] == 'match', range(len(ast1)))
    # filter(lambda x: Diff('move', x.index_pair) not in diff, diff)

    for before, after in pairwise(gumtree_diff.matches + [(len(gumtree_diff.base_ast.tree), len(gumtree_diff.head_ast.tree))]):
        if before[0] + 1 != after[0]:
            pattern1 = gumtree_diff.base_ast.tree[before[0] + 1 : after[0]]
            pattern2 = gumtree_diff.head_ast.tree[before[1] + 1 : after[1]]

            if pattern2:
                pattern_begin = min(n.begin for n in pattern2)
                pattern_end = max(n.end for n in pattern2)
                head_code = gumtree_diff.head_ast.code[pattern_begin:pattern_end]


                yield Pattern(pattern1, head_code)
            else:
                yield Pattern(pattern1, "")


def findall_pattern(sub_patterns: list[Pattern], ast: AST):
    def match(pattern_node: ASTNode, node: ASTNode):
        return node.name == pattern_node.name

    sub_patterns = list(sub_patterns)

    for ranges in product(
        *(
            filter(
                lambda i: all(
                    starmap(match, zip(sub_pattern.base_sub_ast, ast.tree[i[0] :]))
                ),
                enumerate(range(len(sub_pattern.base_sub_ast), len(ast.tree) + 1)),
            )
            for sub_pattern in sub_patterns
        )
    ):
        if all(r1[1] <= r2[0] for r1, r2 in pairwise(ranges)):
            yield ranges
            """
            replaced_code = ast.code
            i = 0
            for (b, e), sub_pattern in zip(ranges, sub_patterns):
                _b = min(n.begin for n in ast.tree[b:e])
                _e = max(n.end for n in ast.tree[b:e])

                replaced_code = (
                    replaced_code[: _b + i]
                    + sub_pattern.head_sub_code
                    + replaced_code[_e + i :]
                )

                for base_i, (rb, re) in sub_pattern.replacing_nodes:
                    replaced_code = (
                        replaced_code[: _b + rb + i]
                        + ast.tree[b + base_i].value
                        + replaced_code[_b + re + i :]
                    )
                    i += len(ast.tree[b + base_i].value) - re + rb

                i += len(sub_pattern.head_sub_code) - _e + _b
            yield replaced_code
            """
