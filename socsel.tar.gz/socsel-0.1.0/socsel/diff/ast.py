import math
import re
from re import search

from ..classes.ast import AST, ASTNode, Code
from ..util.file import make_file
from ..util.shell import exec


def parse_code(code: Code) -> AST:
    ast: list[ASTNode] = []
    before_parent = []
    for i, line in enumerate(exec("gumtree", "parse", make_file(code))):
        matched = re.match(
            r"( *)((.+) \[(\d+),(\d+)\])", line
        )

        if not matched:
            return None

        indent, label, name, begin, end = matched.groups()

        if len(indent) // 4 == len(before_parent):
            parent = before_parent
        elif len(indent) // 4 > len(before_parent):
            parent = before_parent + [i - 1]
        elif len(indent) // 4 < len(before_parent):
            parent = before_parent[: len(indent) // 4]

        if names := re.match(r"([^ ]+): (.+)", name):
            ast.append(ASTNode(int(begin), int(end), label, * names.groups(), parent))
        else:
            ast.append(ASTNode(int(begin), int(end), label, name, name, parent))

        before_parent = ast[-1].parent

    return AST(code, ast)


def extract_declaration_nodes(ast: AST) -> set[ASTNode]:
    declarations = set()
    for node in filter(lambda x: x, ast):
        path_str = "/".join(map(str, node.parent))
        if search("declarations/[0-9]+/id", path_str):
            declarations.add(node["name"])
        elif len(node.parent) >= 2 and (node.parent[-2:]) == ["left", "property"]:
            declarations.add(node["name"])
        elif len(node.parent) >= 2 and node.parent[-2] == "params":
            declarations.add(node["name"])
        elif node.parent[-1] == "param":
            declarations.add(node["name"])
        elif node.parent[-1] == "key":
            declarations.add(node["name"])
        elif (
            node.parent[-1] == "id"
            and ast[node.parent[:-1]].name == "FunctionDeclaration"
        ):
            declarations.add(node["name"])

    return declarations
