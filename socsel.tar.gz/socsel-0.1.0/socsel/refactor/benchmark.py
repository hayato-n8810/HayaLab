from random import sample

from ..util.file import make_file
from ..util.shell import exec


def measure(codes: list[str]):
    test_codes = []
    for i, code in enumerate(codes):
        test_codes.append(
            make_file(
                "const micro_benchmark = () => {\n" + code + "}\n"
                "for(var i=0; i<5; i++) micro_benchmark();\n"
                "const a = performance.now();\n"
                "for(var i=0; i<1000; i++) micro_benchmark();\n"
                "const b = performance.now();\n"
                "console.log(b-a);",
                i,
            )
        )

    sum_log = [[] for _ in test_codes]

    for _ in range(5):
        for i, test_path in sample(list(enumerate(test_codes)), len(test_codes)):
            if r := exec(["timeout", "60", "node", test_path]):
                sum_log[i].append(float(r.split("\n")[-2]))
            else:
                sum_log[i].append(None)

    return sum_log


def test(codes: list[str]):
    test_codes = []
    for i, code in enumerate(codes):
        test_codes.append(make_file(code, i))

    sum_log = [[] for _ in test_codes]

    for _ in range(10):
        for i, test_path in sample(enumerate(test_codes), len(test_codes)):
            sum_log[i].append(exec("timeout", "60", "node", test_path).split("\n")[-1])

    return sum_log
