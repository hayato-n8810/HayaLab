from ..util.file import make_file
from ..util.shell import exec


def format(code: str):
    filename = make_file(code)
    exec("npx", "@biomejs/biome", "format", "--write", filename)
    with open(filename) as f:
        return f.read()
