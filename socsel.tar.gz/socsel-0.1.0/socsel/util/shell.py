from json import loads
from subprocess import run


def exec(*command: str) -> list[str] | None:
    result = run(
        command,
        capture_output=True,
        text=True,
    )
    if result.returncode:
        return None
    return result.stdout.split("\n")


def exec_json(*command: str) -> str | None:
    result = run(
        command,
        capture_output=True,
        text=True,
    )
    if result.returncode:
        return None
    return loads(result.stdout)


def ssh(command: list[str]) -> str:
    return exec(["ssh", "-i", "$USER", "133.42.160.101"] + command)
