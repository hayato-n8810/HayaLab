from multiprocessing import Pool
from os.path import isdir
from typing import Callable, Optional

from ..classes.dataset import Dataset
from .data import load_data, save_data


def autorun(
    func: Callable,
    loading_dataset: Optional[Dataset],
    storing_dataset: Dataset,
    process_n: int = 1,
) -> None:
    """実行
    Args:
        func(Callable): 実行する関数
        loading_dataset(Optional[Dataset]): 読込データセット
        storing_dataset(Dataset): 保存データセット
        process_n(int): 並列に実行するプロセス数
    """
    if isdir(storing_dataset.dirpath):
        print("\n[ skipped ]")
        return

    print("\n[ storing ]")

    if loading_dataset:
        save_data(Pool(process_n).imap_unordered(func, load_data(loading_dataset)))
    else:
        save_data(func())

    print("\n[ success ]")
