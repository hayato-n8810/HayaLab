from atexit import register
from collections.abc import Generator, Iterable
from dataclasses import asdict
from importlib import import_module
from itertools import count
from json import dump, load
from os import getpid, listdir, makedirs, path
from os.path import isdir
from shutil import move, rmtree
from types import TracebackType
from typing import Any, Callable, Optional, Self


def make_file(*texts: str) -> str | list[str]:
    filenames = []
    for i, text in enumerate(texts):
        makedirs(f"/tmp/{getpid()}", exist_ok=True)
        filename = f"/tmp/{getpid()}/{i}.js"
        with open(filename, "w") as f:
            f.write(text)

        filenames.append(filename)

    register(delete_tmp_dir, f"/tmp/{getpid()}")
    if len(filenames) == 1:
        return path.abspath(filenames[0])

    return list(map(path.abspath, filenames))


def make_tmp_dir(text: str, i: int = 0) -> str:
    pass


def delete_tmp_dir(tmp_repo: str):
    if path.isdir(tmp_repo):
        rmtree(tmp_repo)


def recreate_dir(dataset):
    if isdir(dataset.tmp_dirpath):
        rmtree(dataset.tmp_dirpath)

    makedirs(dataset.tmp_dirpath)


def move_dir(dataset):
    if isdir(dataset.dirpath):
        rmtree(dataset.dirpath)

    move(dataset.tmp_dirpath, dataset.dirpath)
