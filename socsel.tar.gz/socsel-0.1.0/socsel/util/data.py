from atexit import register
from collections.abc import Generator, Iterable
from dataclasses import asdict
from importlib import import_module
from itertools import count
from json import dump, load
from os import getpid, listdir, makedirs, path
from os.path import isdir
from shutil import move, rmtree
from types import TracebackType
from typing import Any, Callable, Optional, Self

from tqdm import tqdm
from tqdm.contrib import tenumerate


def flatten(array, el_type):
    if array is None:
        return

    if type(array) is el_type:
        yield array
    else:
        yield from map(flatten, array)


def load_data(datatype, path: str):
    for filename in listdir(path):
        with open(f"{path}/{filename}") as rf:
            yield datatype(**load(rf))


def save_data(dataset):
    makedirs(dataset.dirpath)
    for i, data in enumerate(flatten(dataset, dataset.datatype)):
        with open(f"{dataset.dirpath}/{i}", "w") as wf:
            dump(asdict(data), wf)
