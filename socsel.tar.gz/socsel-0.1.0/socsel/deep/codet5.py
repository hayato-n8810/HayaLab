#import torch
#from torch.optim import AdamW
#from torch.utils.data import DataLoader, Dataset
#from transformers import RobertaTokenizer, T5ForConditionalGeneration


def main(train_data):
    device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")

    class T5Dataset(Dataset):
        def __init__(self, data, tokenizer):
            self.data = data
            self.tokenizer = tokenizer

        def __len__(self):
            return len(self.data)

        def __getitem__(self, idx):
            inputs = self.tokenizer.encode_plus(
                self.data[idx]["input"],
                max_length=512,
                padding="max_length",
                truncation=True,
                return_tensors="pt",
            )

            outputs = self.tokenizer.encode_plus(
                self.data[idx]["output"],
                max_length=512,
                padding="max_length",
                truncation=True,
                return_tensors="pt",
            )

            return {
                "attention_mask": inputs["attention_mask"].squeeze().to(device),
                "input_ids": inputs["input_ids"].squeeze().to(device),
                "labels": outputs["input_ids"].squeeze().to(device)
            }
    
    model = T5ForConditionalGeneration.from_pretrained("Salesforce/codet5p-220m").to(device)
    tokenizer = RobertaTokenizer.from_pretrained("Salesforce/codet5p-220m")

    train_dataset = T5Dataset(train_data, tokenizer)
    # test_dataset = T5Dataset(test_data, tokenizer)

    train_loader = DataLoader(train_dataset, batch_size=16, shuffle=True)
    # test_loader = DataLoader(test_dataset, batch_size=16)

    optimizer = AdamW(model.parameters(), lr=2e-5)

    for epoch in range(5):
        model.train()
        for inputs in train_loader:
            optimizer.zero_grad()
            model(**inputs).loss.backward()
            optimizer.step()

        model.save_pretrained(f"./data/model/model_epoch_{epoch}")
