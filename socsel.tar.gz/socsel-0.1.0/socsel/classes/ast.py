from dataclasses import dataclass
from typing import NewType

Code = NewType("Code", str)


@dataclass
class ASTNode:
    begin: int
    end: int
    label: str
    name: str
    value: str
    parent: list[int]


@dataclass
class AST:
    code: Code
    tree: list[ASTNode]


@dataclass
class GumtreeNodeDiff:
    relation: str
    base: ASTNode | None
    head: ASTNode | None

"""
@dataclass
class GumtreeDiff:
    diff: list[GumtreeNodeDiff]
    base_ast: AST
    head_ast: AST
"""

@dataclass
class GumtreeAction:
    name: str
    tree: int | None


@dataclass
class GumtreeDiff:
    matches: list[tuple[int, int]]
    actions: list[GumtreeAction]
    base_ast: AST
    head_ast: AST


@dataclass
class Pattern:
    base_sub_ast: list
    head_sub_code: str
