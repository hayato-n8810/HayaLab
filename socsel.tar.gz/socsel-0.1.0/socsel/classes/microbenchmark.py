from dataclasses import dataclass


@dataclass
class MicroBM:
    setup_code: str
    test_codes: list[str]
