from dataclasses import dataclass
from typing import NewType


@dataclass
class Dataset[T]:
    dirpath: str
    datatype: T
